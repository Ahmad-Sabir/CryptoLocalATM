@extends('Front_layout.nav')
@section('content')
    @include('Front_layout.slider')
    @include('Front_layout.fees')
    @include('Front_layout.price')
    @include('Front_layout.about')
@endsection



