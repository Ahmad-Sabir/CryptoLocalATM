@extends('Front_layout.index')
@section('content')
@include('user.dashboard')
{{-- <div class="main">
            <div class="col-sm-9">
                <ul class="nav nav-tabs">
                    <li class="active"><a data-toggle="tab" href="#home">Profile</a></li>
                    <li><a data-toggle="tab" href="#messages">Edit</a></li>
                  </ul>
                    <div class="tab-content">
                        <div class="tab-pane active" id="home">
                         <hr>
                            <div class="text-center">
                             <h2 style="text-align:center">User Profile</h2>
                             <div class="card">
                             <img src="http://ssl.gstatic.com/accounts/ui/avatar_2x.png" style="text-align:center; width:30%" class="avatar img-circle img-thumbnail" alt="avatar">
                             <h6>Upload a photo</h6>
                             <input type="file" class="text-center center-block file-upload">
                               <h1> {{ Auth::user()->name }} {{ Auth::user()->lname }}</h1>
                               <p class="title">{{ Auth::user()->email }}<br></p>
                              <h3>  {{ Auth::user()->country }}</h3>

                             </div>
                           </div>

                        </div><!--/Update-pane-->
                    <div class="tab-pane" id="messages">
                   <h2 style="text-align:center">Update</h2>
                    <hr>
                        <form class="form" action="updateprofile" method="post" id="registrationForm">
                            <div class="form-group">

                                <div class="col-xs-6">
                                    <label for="first_name"><h4>First name</h4></label>
                                    <input type="text" class="form-control" name="name" id="first_name" placeholder="{{ Auth::user()->name }}" title="enter your first name if any.">
                                </div>
                            </div>
                            <div class="form-group">

                                <div class="col-xs-6">
                                    <label for="last_name"><h4>Last name</h4></label>
                                    <input type="text" class="form-control" name="lname" id="last_name" placeholder="{{ Auth::user()->lname }}" title="enter your last name if any.">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-6">
                                    <label for="email"><h4>Email</h4></label>
                                    <input type="email" class="form-control" name="email" id="email" value="{{ Auth::user()->email }}"  title="enter your email.">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-6">
                                    <label for="country"><h4>Country</h4></label>
                                    <input type="text" class="form-control" id="location" name="country" value="{{ Auth::user()->country }}" title="enter a location">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-12">
                                        <br>
                                       <center> <button style="color: #fff;
                                        background-color: #ebe70a;
                                        border-color: #eff30e;" class="btn btn-lg btn-success" type="submit"><i class="glyphicon glyphicon-ok-sign"></i> Update</button></center>
                                    </div>
                            </div>
                        </form>
                    </div><!--/tab-pane-->
              </div><!--/tab-content-->
            </div><!--/col-9-->
        </div><!--/row--><hr>
    </div>--}}
  @endsection
  <script>
 $(document).ready(function() {
    var readURL = function(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('.avatar').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }


    $(".file-upload").on('change', function(){
        readURL(this);
    });
 });
 </script>
