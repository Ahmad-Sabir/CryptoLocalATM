
      <section class="dashboard">
        <div class="row m-0">
           <div class="col-md-2 sidebar_bg" data-aos="fade-in" data-aos-duration="1000">
              <div class="sidebar">
                 <div class="sidebar_logo">
                    <img src="images/logo.png" alt="">
                    <h3>Crypto</h3>
                 </div>
                 <div class="sidebar_links">
                    <ul>
                       <li>
                          <a href="#" class="active_sidebar"> <i class="fa fa-dashboard"></i> Dasboard</a>
                       </li>
                       <li>
                          <a href="#"> <i class="fa fa-briefcase"></i> Buy</a>
                       </li>
                       <li>
                          <a href="#"> <i class="fa fa-sort"></i> purchase order</a>
                       </li>
                       <li>
                          <a href="#"> <i class="fa fa-ticket"></i> Support Ticket</a>
                       </li>
                       <li>
                          <a href="#"> <i class="fa fa-cog"></i> Settings</a>
                       </li>
                    </ul>
                 </div>
              </div>
           </div>
           <div class="col-md-10 p-0">
              <div class="detail_section" data-aos="zoom-in" data-aos-duration="1000">
                 <div class="main_title">
                    <h3>Dashboard</h3>
                    <div class="dashboard_dropdown">
                       <i class="fa fa-user-circle-o"></i>
                       <ul>
                          <li class="drop-down">
                             <a class="nav_link ">Dashboard</a>
                             <ul>
                                <li><a href="#">Profile</a></li>
                                <li><a href="{{ route('logout') }}"  onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">Logout</a></li>
                             </ul>
                          </li>
                       </ul>
                    </div>
                 </div>
                 <div class="vouchers_btns">
                    <button type="button" class="btn">Order Voucher</button>
                    <button type="button" class="btn">Reedem voucher</button>
                 </div>
                 <div class="row">
                    <div class="col-md-6">
                       <div class="chart">
                          <div id="chartContainer" style="height: 330px; width: 100%;"></div>
                       </div>
                    </div>
                    <div class="col-md-6">
                       <div class="detail_tables">
                          <h3>Last Order Placed</h3>
                          <table class="table text-center mb-4">
                            <thead>
                              <tr>
                                <th scope="col">Amount</th>
                                <th scope="col">BTR</th>
                                <th scope="col">Date</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td>€11,000.00</td>
                                <td>120.00</td>
                                <td>Nov 12, 2020</td>
                              </tr>
                            </tbody>
                          </table>
                          <h3>Recent Orders</h3>
                          <table class="table text-center mb-4">
                            <thead>
                              <tr>
                                <th scope="col">Amount</th>
                                <th scope="col">BTR</th>
                                <th scope="col">Date</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td>€8,000.00</td>
                                <td>100.00</td>
                                <td>Nov 12, 2020</td>
                              </tr>
                              <tr>
                                <td>€12,000.00</td>
                                <td>130.00</td>
                                <td>Nov 12, 2020</td>
                              </tr>
                              <tr>
                                <td>€5,000.00</td>
                                <td>20.00</td>
                                <td>Nov 12, 2020</td>
                              </tr>
                              <tr>
                                 <td colspan="3" class="show_more"><p>Show More</p></td>
                              </tr>
                            </tbody>
                          </table>
                       </div>
                    </div>
                 </div>
              </div>
           </div>
        </div>
     </section>
