<!DOCTYPE html>

<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
   .card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.title {
  color: grey;
  font-size: 18px;
}
    .sidebar {
    height: 80%;
    width: 260px;
    top: 164px;
    left: 0;
    background-color: rgb(39, 39, 39);
    overflow-x: hidden;
    padding-top: 60px;
    }

    .sidebar a {
    padding: 10px 12px 10px 20px;
    text-decoration: none;
    font-size: 20px;
    color: #ffffff;
    display: block;
    }

    .sidebar a:hover {
    color: #f0ec0c;
    }

    .main {
    margin-left: 250px;
    margin-top: -486px;
    padding: 0px 10px;
    }

    @media screen and (max-height: 450px) {
    .sidebar {padding-top: 95px;}
    .sidebar a {font-size: 18px;}
    }
</style>
</head>
<body>

<div class="sidebar">
    <a href="profile"><i class="material-icons" style=" color:#eeff00">dashboard</i>&nbsp; Dashboard</a>
    <a href="#"><i class="fa fa-shopping-bag"  style="color:#eeff00"></i>&nbsp; Buy</a>
    <a href="#"><i class="fa fa-shopping-bag"  style="color:#eeff00"></i>&nbsp; Purchase Order</a>
    <a href="support_ticket"><i class="fa fa-ticket" style="color:#eeff00"></i>&nbsp; Support Tickets</a>
    <a href="#"><i class="material-icons" style="color:#eeff00">settings</i>&nbsp; Setting</a>
</div>

</body>
</html>
