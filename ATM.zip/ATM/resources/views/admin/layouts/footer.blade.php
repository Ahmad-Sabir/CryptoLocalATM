<footer class="footer">
    <div class="container-fluid">

        <div class="copyright">
            &copy; {{ now()->year }} {{ __('made with') }} <i class="tim-icons icon-heart-2"></i> {{ __('by') }}
            <a href="#" target="_blank">{{ __('CryptoATM') }}</a>
        </div>
    </div>
</footer>
