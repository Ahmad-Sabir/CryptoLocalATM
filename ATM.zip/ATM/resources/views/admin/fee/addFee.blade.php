
@extends('admin.layouts.app')

@section('content')


    <div class="set_form">
        <div class="card">
            <div class="card-header">
                <h5 class="title"></h5>
            </div>
            <form method="post" action="/feesubmit" autocomplete="off" enctype="multipart/form-data">
                <div class="card-body">
                    @csrf

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="inputEmail4"><b>Admin fee</b></label>
                            <input type="text" name="admin_fee" class="form-control">
                        </div>
                        <div class="form-group col-md-6">
                            <label for="inputPassword4">Shiping fee</label>
                            <input type="text" name="ship_fee" class="form-control"   >
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="inputEmail4"><b>Low minning fee</b></label>
                            <input type="text" name="low_fee" class="form-control">
                        </div>
                        <div class="form-group col-md-6">
                            <label for="inputPassword4">Medium Mining fee</label>
                            <input type="text" name="medium_fee" class="form-control"   >
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="inputEmail4"><b>Normal mining fee</b></label>
                            <input type="text" name="normal_fee" class="form-control">
                        </div>
                        <div class="form-group col-md-6">
                            <label for="inputPassword4">High Mining fee</label>
                            <input type="text" name="high_fee" class="form-control"   >
                        </div>
                        <div class="form-group col-md-6">
                            <label for="inputPassword4">Maximum Purchase</label>
                            <input type="text" name="maximum_purchase" class="form-control"   >
                        </div>
                        <div class="form-group col-md-6">
                            <label for="inputPassword4">Minimum Purchase</label>
                            <input type="text" name="minimum_purchase" class="form-control"   >
                        </div>
                    </div>



                    <div class="card-footer pull-right">
                        <button type="submit" class="btn btn-fill btn-primary">Add Fee</button>

                    </div>
                </div>
            </form>
        </div>
    </div>

@endsection
