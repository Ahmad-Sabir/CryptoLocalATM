@extends('admin.layouts.app')
@section('content')
    <div class="set_form">
        <div class="card">

            <div class="card-header">
                <h5 class="title">Client Edit</h5>
            </div>
            @if(Session::has('message'))
                <p class="alert alert-info">{{ Session::get('message') }}</p>
            @endif
            <form method="post" action="{{route('updateClient',[$data->id])}}" autocomplete="off" enctype="multipart/form-data">
                <div class="card-body">
                    @csrf
                    <div class="form-row">

                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Name</label>
                            <input type="text" name="name" value="{{$data->name}}" class="form-control">
                        </div>

                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Last Name</label>
                            <input type="text" name="lname" value="{{$data->lname}}" class="form-control">
                        </div>

                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Address</label>
                            <input type="text" name="address" value="{{$data->country}}" class="form-control">
                        </div>

                        <div class="form-group col-md-6">
                            <label for="inputEmail4">email</label>
                            <input type="email" name="email" value="{{$data->email}}" class="form-control">
                        </div>

                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Password</label>
                            <input type="password" name="password" value="" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label class="btn btn-outline-neutral">Client Image
                            <input type="file" name="client_image_id" >
                        </label>
                    </div>
                </div>
                <div class="card-footer pull-right">
                    <button type="submit" class="btn btn-fill btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>

@endsection
