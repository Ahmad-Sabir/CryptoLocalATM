@extends('admin.layouts.app')

@section('content')
<!-- <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('ADMIN Dashboard') }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    {{-- {{ __('You are logged in as admin') }} --}}
                </div>
            </div>
        </div>
    </div>
</div> -->
<div class="row">
        <div class="col-lg-4">
            <div class="btn card card-chart">
                
                <div class="card-header">
                <a href="#">
                    <h5 class="card-category text-primary">Total Orders</h5>
                    <h3 class="card-title counter"><i class="tim-icons icon-single-02 text-primary"></i> 1</h3>
                </a>
                </div>
            </div>
        </div>
        <div class=" col-lg-4">
            <div class="btn card card-chart">
                <div class="card-header">
                    <a href="#">
                    <h3 class="card-category text-info">Total Clients</h3>
                    <h3 class="card-title counter"><i class="tim-icons icon-single-02 text-info"></i>5</h3>
                    </a>
                </div>
            </div>
        </div>
        <div class=" col-lg-4">
            <div class="btn card card-chart">
           
                
                <div class="card-header">
               
                    <h5 class="card-category text-success">Total Users</h5>
                    <h3 class="card-title counter"><i class="tim-icons icon-send text-success"></i>6</h3>
              
                </div>
                

            </div>
        </div>
        <div class=" col-lg-4">
            <div class="btn card card-chart">
           
                <a href="#">
                <div class="card-header">
                 
                    <h5 class="card-category text-warning">Total Transections</h5>
                    <h3 class="card-title counter"><i class="tim-icons icon-chart-bar-32 text-warning"></i>17</h3>
                 
                </div>
                </a>

            </div>
        </div>
    </div>
@endsection
