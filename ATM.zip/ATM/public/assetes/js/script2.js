$(document).ready(function(){
	
	$('select').niceSelect();

	$('.main_box').click(function() {
		/* Act on the event */
		$('.main_box').removeClass('active_currency');
		$(this).addClass('active_currency');
	});

	$(window, document, undefined).ready(function() {

  $('.input').blur(function() {
    var $this = $(this);
    if ($this.val())
      $this.addClass('used');
    else
      $this.removeClass('used');
  });
  
  });


$('#tab1').on('click' , function(){
    $('#tab1').addClass('login-shadow');
   $('#tab2').removeClass('signup-shadow');
});

$('#tab2').on('click' , function(){
    $('#tab2').addClass('signup-shadow');
   $('#tab1').removeClass('login-shadow');
});

$('.main_country').click(function(event) {
	/* Act on the event */
	$('.country_list').toggle();
});

//  WOW.js Animation
  var wow = new WOW();
  wow.init();

// AOS Animation
AOS.init();
});