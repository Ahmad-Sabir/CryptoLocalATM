<?php
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//  Route ::redirect('/','/en');
//  Route::group(['prefix' => '{language }'], function () {



Route::get('/', function () {
    return view('welcome');
});

Auth::routes();
// });

Route::post('reset-password','LoginController@resetPassword')->name('reset-password');
Route::get('profile','ProfileController@showprofile')->name('profile');
Route::get('/user', 'UserController@index')->name('user');
Route::get('support_ticket', 'SupportTicket@support_ticket')->name('support_ticket');
Route::post('submitticket','ChatController@submitticket');

//admin
Route::get('/admin', 'AdminController@index')->name('admin');
Route::group(['middleware' => 'auth'], function () {

// CodesController

    Route::get('codes','CodesController@codes')->name('code.index');
    Route::get('add-code','CodesController@addcodes')->name('addCode');
    Route::post('create-code','CodesController@createCode')->name('createCode');
    Route::get('edit-code/{id}','CodesController@editCode')->name('editCode');
    Route::post('update-code/{id}','CodesController@updateCode')->name('updateCode');
    Route::get('delete-code/{id}','CodesController@deleteCode')->name('deleteCode');
    Route::post('create-csv','CodesController@addCSVfile')->name('addCSVfile');
    Route::get('export', 'CodesController@export')->name('export');

    // Feee Controller
    Route::get('fee','FeeController@fee')->name('fee.index');
    Route::post('/feesubmit','FeeController@Add');
    Route::view('addfee','admin.fee.addFee');
    Route::get('editFee/{id}', 'FeeController@edit');
    Route::post('update/{id}', 'FeeController@update')->name('update');
    Route::get('delete/{id}','FeeController@Delete')->name('Delete');

    //client controller
    Route::get('showclient','ClientDataController@showclient')->name('showclient');
    Route::get('client-edit/{id}','ClientDataController@clientEdit')->name('clientEdit');
    Route::get('add-client','ClientDataController@addClient')->name('add-client');
    Route::post('create-client','ClientDataController@createClient')->name('createClient');
    Route::post('update-client/{id}','ClientDataController@updateClient')->name('updateClient');
    Route::get('client-delete/{id}','ClientDataController@clientDelete')->name('clientDelete');


//Order controller
Route::get('order','OrderController@order')->name('order.index');
Route::post('order','OrderController@Add')->name('createorder');


// Chat Controllers
Route::get('chats','ChatController@chats')->name('chat.index');
Route::get('showChat/{ticket_no}','ChatController@showChat')->name('chat.show');
Route::post('/adminReply','ChatController@adminReply');

    //Login History
Route::get('loginhistory','LoginHistory@loginhistory')->name('login.index');

});

