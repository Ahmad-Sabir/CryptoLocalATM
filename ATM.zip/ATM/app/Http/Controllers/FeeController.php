<?php

namespace App\Http\Controllers;

use App\FeeModel;
use Illuminate\Http\Request;

class FeeController extends Controller
{
    public function fee()
    {
        $data = FeeModel::orderBy('created_at', 'asc')->get();
        return view('admin.fee.feeHome', compact('data'));
    }


    public function Add(Request $req)
    {
        $resto = new FeeModel();
        $resto->admin_fee = $req->input('admin_fee');
        $resto->ship_fee= $req->input('ship_fee');
        $resto->low_fee = $req->input('low_fee');
        $resto->medium_fee= $req->input('medium_fee');
        $resto->normal_fee= $req->input('normal_fee');
        $resto->high_fee= $req->input('high_fee');
        $resto->maximum_purchase= $req->input('maximum_purchase');
        $resto->minimum_purchase= $req->input('minimum_purchase');



        $resto->save();
        $req->session()->flash('status', ' Submitted successfully');
        return redirect('fee');
    }

    public function editfee($id)
    {
        $data = FeeModel::find($id);
        return view('admin.editfee.editfee' , compact($data));
    }

    public function Delete($id)
    {
        $data = FeeModel::find($id);
        $data->delete();
        return redirect('fee');
       

    }
    public function  edit($id)
    {
        $data =FeeModel::find($id);
        return view('admin.fee.editFee', ['data'=>$data]);
    }
    public  function update(Request $req, $id)
    {
        $resto = FeeModel::find($id);
        $resto->admin_fee=$req->input('admin_fee');
        $resto->ship_fee=$req->input('ship_fee');
        $resto->low_fee=$req->input('low_fee');
        $resto->medium_fee=$req->input('medium_fee');
        $resto->normal_fee=$req->input('normal_fee');
        $resto->high_fee=$req->input('high_fee');
        $resto->maximum_purchase=$req->input('maximum_purchase');
        $resto->minimum_purchase=$req->input('minimum_purchase');

        $resto->save();
        $req->session()->flash('status',' Updated  successfully');
        return redirect('fee');
    }
}
