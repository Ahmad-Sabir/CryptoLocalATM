<?php

namespace App\Http\Controllers;
use App\ClientData;
use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class ClientDataController extends Controller
{
    public function showclient(){
        $data = User::all()->except(Auth::id());

        return view('admin.client.client-home',compact('data'));
    }
    public function clientEdit($id){

        $data=User::where('id',$id)->get()->first();
        return view('admin.client.edit-client',compact('data'));
    }
    public function createClient(Request $request){
        if ($request->hasFile('client_image_id')) {
            $image = $request->file('client_image_id');
            $imageName = time() . "-" .$image->extension();
            $imagePath = public_path() . 'black/img/';
            $image->move($imagePath, $imageName);
            $imageDbPath = $imageName;
        }

        $data=User::create([
            'name'=>$request['name']??'',
            'lname'=>$request['lname']??'',
            'email'=>$request['email']??'',
            'password'=> bcrypt($request['password']??''),
            'country'=>$request['address']??'',
            'client_image_id'=>$imageDbPath??'',
        ]);

        if ($data){
            return redirect()->route('showclient')->with('message','Created successfully');
        }
    }
    public function updateClient(Request $request){


        if($files=$request->file('client_image_id')){
            $name_client_image = $files->getClientOriginalName();
            $filename = pathinfo($name_client_image, PATHINFO_FILENAME);
            $files->move('black/img/', $name_client_image);
        }

        if($files=$request->file('card_image_id')){
            $name_nic_image = $files->getClientOriginalName();
            $filename = pathinfo($name_nic_image, PATHINFO_FILENAME);
            $files->move('black/img/', $name_nic_image);
        }

        $client = User::find($request->id);
        $client->name = $request->name;
        $client->lname = $request->lname;
        $client->country = $request->address;
        $client->email = $request->email;
        $client->password = bcrypt($request->password);
        $client->client_image_id = $name_client_image;

        $client->save();

        if ($client) {
            return redirect()->route('showclient')->with('message','updated successfully');
        }
    }

    public function addClient(){
        return view('admin.client.add-client');
    }



    public function clientDelete($id){
        $data=User::where('id',$id)->delete();

        if($data){
            return redirect()->back()->with('message','Deleted Successfully');
        }
    }

}
