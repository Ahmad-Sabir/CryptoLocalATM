<?php

namespace App\Http\Controllers;
use App\ChatModel;
use Illuminate\Http\Request;

class SupportTicket extends Controller
{
    public function support_ticket()
    {
        return view('user.support_ticket');
    }

}
