<?php $__env->startSection('content'); ?>
        <?php echo $__env->make('user.layouts.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('user.layouts.fees', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('user.layouts.price', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('user.layouts.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 <?php $__env->stopSection(); ?>



 <!-- ///// Login Modal  ////// -->
      <!-- Modal -->
      <div class="modal fade log-sign" id="myModal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
        <div class="modal-dialog ">
           <div class="modal-content">
              <div class="bs-example bs-example-tabs">
                 <ul id="myTab" class="nav nav-tabs">
                    <li id="tab1" class=" active tab-style login-shadow "><a href="#signin" data-toggle="tab">Log In</a></li>
                    <li id="tab2" class=" tab-style "><a href="#signup" data-toggle="tab">Sign Up</a></li>
                 </ul>
              </div>
              <div class="modal-body">
                 <div id="myTabContent" class="tab-content">
                    <div class="tab-pane fade active in show" id="signin">
                       <form method="POST" action="<?php echo e(route('login')); ?>" class="form-horizontal">
                        <?php echo csrf_field(); ?>
                          <fieldset>
                             <!-- Sign In Form -->
                             <!-- Text input-->
                             <div class="group">
                                <input id="email" type="email" class="input" <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                                <span class="highlight"></span><span class="bar"></span>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <label class="label" for="date">Email address</label>
                             </div>
                             <!-- Password input-->
                             <div class="group">
                                <input id="password" type="password" class="input" <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
                                <span class="highlight"></span><span class="bar"></span>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <label class="label" for="date">Password</label>
                             </div>
                             <em>minimum 6 characters</em>
                             <div class="forgot-link">
                                <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                <label class="form-check-label" for="remember">
                                    <?php echo e(__('Remember Me')); ?>

                                </label>
                                <br>
                                <a href="#forgot" data-toggle="modal" data-target="#forgot-password"> I forgot my password</a>
                             </div>
                             <!-- Button -->
                             <div class="control-group">
                                <label class="control-label" for="signin"></label>
                                <div class="controls">
                                   <button id="signin" type="submit" name="signin" class="btn bitcoin_btn btn-block">Log In</button>
                                </div>
                             </div>
                          </fieldset>
                       </form>
                    </div>
                    <div class="tab-pane fade" id="signup">
                       <form class="form-horizontal">
                          <fieldset>
                             <!-- Sign Up Form -->
                             <!-- Text input-->
                             <div class="group">
                                <input required="" class="input" type="text"><span class="highlight"></span><span class="bar"></span>
                                <label class="label" for="date">First Name</label>
                             </div>
                             <!-- Text input-->
                             <div class="group">
                                <input required="" class="input" type="text"><span class="highlight"></span><span class="bar"></span>
                                <label class="label" for="date">Last Name</label>
                             </div>
                             <!-- Password input-->
                             <div class="group">
                                <input required="" class="input" type="text"><span class="highlight"></span><span class="bar"></span>
                                <label class="label" for="date">Email</label>
                             </div>
                             <!-- Text input-->
                             <div class="group">
                                <input required="" class="input" type="password"><span class="highlight"></span><span class="bar"></span>
                                <label class="label" for="date">Password</label>
                             </div>
                             <em>1-8 Characters</em>
                             <div class="group2">
                                <input required="" class="input" type="text"><span class="highlight"></span><span class="bar"></span>
                                <label class="label" for="date">Country</label>
                             </div>
                             <!-- Button -->
                             <div class="control-group">
                                <label class="control-label" for="confirmsignup"></label>
                                <div class="controls">
                                   <button id="confirmsignup" name="confirmsignup" class="btn bitcoin_btn btn-block">Sign Up</button>
                                </div>
                             </div>
                          </fieldset>
                       </form>
                    </div>
                 </div>
              </div>
           </div>
        </div>
     </div>
     <!--modal2-->
     <div class="modal fade bs-" id="forgot-password" tabindex="0" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
        <div class="modal-dialog ">
           <div class="modal-content">
              <div class="modal-header">
                 <h4 class="modal-title" id="myModalLabel">Password will be sent to your email</h4>
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              </div>
              <div class="modal-body">
                 <form class="form-horizontal">
                    <fieldset>
                       <div class="group">
                          <input required="" class="input" type="text"><span class="highlight"></span><span class="bar"></span>
                          <label class="label" for="date">Email address</label>
                       </div>
                       <div class="control-group">
                          <label class="control-label" for="forpassword"></label>
                          <div class="controls">
                             <button id="forpasswodr" name="forpassword" class="btn bitcoin_btn btn-block">Send</button>
                          </div>
                       </div>
                    </fieldset>
                 </form>
              </div>
           </div>
        </div>
     </div>

<?php echo $__env->make('user.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\multiple\resources\views/user/layouts/index.blade.php ENDPATH**/ ?>