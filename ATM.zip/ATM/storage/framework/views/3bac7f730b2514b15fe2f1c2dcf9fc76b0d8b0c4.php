<?php $__env->startSection('content'); ?>
<?php echo $__env->make('user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main">
    <form class="needs-validation" method="POST" action="submitticket">
        <?php echo csrf_field(); ?>
         <center><h1>Support Tickets</h1></center>
         <input type="hidden" value="<?php echo e(Auth::user()->name); ?>" name="user_from">
         <input type="hidden" name="ticket_no" id="randomCode" class="form-control" placeholder="Click here"  required>

            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

            <div class="col-md-3 mb-3">
            <label for="validationCustom04">Subject</label>
            <input type="text" class="form-control" name="subject" id="validationCustom04" placeholder="Subject" onClick="generateRandomString(10)" required>
            <div class="invalid-feedback">
              Enter Subject.
            </div>
          </div>
          <div class="col-md-6 mb-3">
            <label for="validationCustom03">Message</label>
            <textarea class="form-control" name="message" id="exampleFormControlTextarea1" rows="3"  id="validationCustom03" placeholder="Message" required></textarea>
            <div class="invalid-feedback">
              Enter Message.
            </div>
          </div>
        <button class="btn btn-primary" type="submit">Send</button>
      </form>

      <script>
      (function() {
        'use strict';
        window.addEventListener('load', function() {
          // Fetch all the forms we want to apply custom Bootstrap validation styles to
          var forms = document.getElementsByClassName('needs-validation');
          // Loop over them and prevent submission
          var validation = Array.prototype.filter.call(forms, function(form) {
            form.addEventListener('submit', function(event) {
              if (form.checkValidity() === false) {
                event.preventDefault();
                event.stopPropagation();
              }
              form.classList.add('was-validated');
            }, false);
          });
        }, false);
      })();
      </script>
  </form>
</div>

<script type="text/javascript">

    function generateRandomString(length) {
        var text = "";
        var possible = "abcdefghijklmnopqrstuvwxyz0123456789";

        for (var i = 0; i < length; i++)
            text += possible.charAt(Math.floor(Math.random() * possible.length));

            document.getElementById("randomCode").value = text;

    }

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Front_layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ATM\resources\views/user/support_ticket.blade.php ENDPATH**/ ?>