<footer class="footer">
    <div class="container-fluid">

        <div class="copyright">
            &copy; <?php echo e(now()->year); ?> <?php echo e(__('made with')); ?> <i class="tim-icons icon-heart-2"></i> <?php echo e(__('by')); ?>

            <a href="#" target="_blank"><?php echo e(__('CryptoATM')); ?></a>
        </div>
    </div>
</footer>
<?php /**PATH E:\xampp\htdocs\ATM\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>