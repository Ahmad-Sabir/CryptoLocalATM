<?php $__env->startSection('content'); ?>

          <div class="modal-body">
            <form method="POST" action="<?php echo e(route('login')); ?>" class="form-horizontal">
                <?php echo csrf_field(); ?>
                <div class="login_title">
                    <h2><?php echo e(__('Login')); ?></h2>
                </div>
             <fieldset>
                 <div class="group">
                    <input id="email" type="email" class="input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                    <span class="highlight"></span><span class="bar"></span>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <label class="label" for="date"><?php echo e(__('Email Address')); ?></label>
                </div>
                         <!-- Password input-->
                         <div class="group">
                            <input id="password" type="password" class="input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
                            <span class="highlight"></span><span class="bar"></span>
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <label class="label" for="date"><?php echo e(__('Password')); ?></label>
                         </div>
                         <em>minimum 6 characters</em>
                         <br>
                         <div class="forgot-link">
                            
                            <?php if(Route::has('password.request')): ?>
                            <a href="<?php echo e(route('password.request')); ?>"> <?php echo e(__('I forgot my password')); ?></a>
                            <?php endif; ?>
                        </div>
                         <!-- Button --><br>
                         <div class="control-group">
                            <div class="controls">
                               <button id="signin" type="submit" name="signin" class="btn bitcoin_btn"><?php echo e(__('Log In')); ?></button>
                            </div>
                         </div>
                      </fieldset>
                   </form>
                </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Front_layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ATM\resources\views/auth/login.blade.php ENDPATH**/ ?>