      <!-- ///// Foote /////// -->
      <footer>
        <div class="footer">
           <div class="container">
              <div class="location">
                 <h4>ATC AUTO, PORT LOUIS, Maurice 52, DESCHARTRES ST</h4>
              </div>
              <div class="useful_links">
                 <ul>
                    <li><a href="#"> Fees </a></li>
                    <li><a href="#"> Sign In </a></li>
                    <li><a href="#"> Sign up </a></li>
                    <li><a href="#"> Faq </a></li>
                    <li><a href="#"> Support Ticket </a></li>
                 </ul>
              </div>
              <div class="copyright">
                 <p>© Copyright 2020. All rights reserved.  Terms & Conditions  ,   Privacy Policy</p>
              </div>
           </div>
        </div>
     </footer>
     <!-- ///// End Footer /////// -->
<?php /**PATH E:\xampp\htdocs\multiple\resources\views/user/layouts/footer.blade.php ENDPATH**/ ?>