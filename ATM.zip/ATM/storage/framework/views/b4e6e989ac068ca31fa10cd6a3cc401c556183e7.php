<?php $__env->startSection('content'); ?>
    <style>

        .sidebar .sidebar-wrapper>.nav [data-toggle="collapse"]~div>ul>li>a i, .sidebar .sidebar-wrapper .user .info [data-toggle="collapse"]~div>ul>li>a i, .off-canvas-sidebar .sidebar-wrapper>.nav [data-toggle="collapse"]~div>ul>li>a i, .off-canvas-sidebar .sidebar-wrapper .user .info [data-toggle="collapse"]~div>ul>li>a i {
            line-height: 32px;
        }
        .custom_color , .sorting_1 , table.dataTable.stripe tbody tr.odd, table.dataTable.display tbody tr.odd {
            background: #27293d !important;
        }
        .dataTables_wrapper .dataTables_length select {
            color: #fff !important;
        }
        .dataTables_wrapper .dataTables_length, .dataTables_wrapper .dataTables_filter, .dataTables_wrapper .dataTables_info, .dataTables_wrapper .dataTables_processing, .dataTables_wrapper .dataTables_paginate {
            color: #fff !important;
        }
        .dataTables_wrapper .dataTables_paginate .paginate_button.disabled, .dataTables_wrapper .dataTables_paginate .paginate_button.disabled:hover, .dataTables_wrapper .dataTables_paginate .paginate_button.disabled:active {
            color: #e7e4e4 !important;
        }
        .dataTables_wrapper .dataTables_paginate .paginate_button , .dataTables_wrapper .dataTables_filter input {
            color: #fff !important;
        }
        .card-body {
            overflow-x: scroll;
            overflow-y: hidden;
        }
    </style>
    <div class="content">
        <div class="row">
            <?php if(Session::has('message')): ?>
                <p class="alert alert-success"><?php echo e(Session::get('message')); ?></p>
            <?php endif; ?>
            <div class="col-md-12">
                <div class="card ">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-8">
                                <h4 class="card-title">Fee Details</h4>
                                <a href="addfee" class="btn btn-success">Add Fee</a>

                            </div>
                            <div class="col-md-4">

                            </div>
                        </div>
                    </div>
                    <div class="card-body">

                        <div class="">
                            <table id="myTable" class="text-primary display table tablesorter">
                                <thead class="text-primary">
                                <tr><th scope="col">Admin Fee</th>
                                    <th scope="col">Shiping  Fee</th>
                                    <th scope="col">Low Mining Fee</th>
                                    <th scope="col">Medium Mining Fee</th>
                                    <th scope="col">Normal Mining Fee</th>
                                    <th scope="col">High Mining Fee</th>
                                    <th scope="col">maximum_purchase</th> a
                                    <th scope="col">minimum_purchase</th>
                                </tr></thead>
                                <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="custom_color" >
                                        <td><?php echo e($datum->admin_fee); ?></td>
                                        <td><?php echo e($datum->ship_fee); ?></td>
                                        <td ><?php echo e($datum->low_fee); ?></td>
                                        <td><?php echo e($datum->medium_fee); ?></td>
                                        <td><?php echo e($datum->normal_fee); ?></td>
                                        <td><?php echo e($datum->high_fee); ?></td>
                                        <td><?php echo e($datum->maximum_purchase); ?></td>
                                        <td><?php echo e($datum->minimum_purchase); ?></td>



                                        <td class="text-right">
                                            <div class="dropdown">
                                                <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i class="fas fa-ellipsis-v"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                                    <a class="dropdown-item" href="<?php echo e(url('editFee/'. $datum->id)); ?>">Edit</a>
                                                    <a class="dropdown-item" href="<?php echo e(url('delete/'. $datum->id)); ?>">Delete</a>
                                                </div>
                                            </div>
                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card-footer py-4">
                        <nav class="d-flex justify-content-end" aria-label="...">

                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', ['page' => __('User Profile'), 'pageSlug' => 'profile'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ATM\resources\views/admin/fee/feeHome.blade.php ENDPATH**/ ?>