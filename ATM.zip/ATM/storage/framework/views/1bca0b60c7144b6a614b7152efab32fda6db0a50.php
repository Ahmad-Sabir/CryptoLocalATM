   <!-- //////  Main Carousal  /////// -->
   <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner">
       <div class="carousel-item active" data-aos="zoom-in-right" data-aos-duration="1500">
          <img src="<?php echo e(asset('assetes/images/Mask.png')); ?>" class="img-fluid" alt="">
          <div class="slider_text">
             <h1>Inovative & Secure. <br>
                Crypto Exchange!
             </h1>
             <p>Lorem Ipsum is simply dummy text of the printing and <br> typesetting industry. <br>
                Lorem Ipsum has been the industry's standard dummy text <br> ever since the 1500s,
             </p>
             <button type="button"> Buy Now</button>
          </div>
       </div>
       <div class="carousel-item">
          <img src="<?php echo e(asset('assetes/images/Mask1.png')); ?>" class="img-fluid" alt="">
          <div class="slider_text">
             <h1>Inovative & Secure. <br>
                Crypto Exchange!
             </h1>
             <p>Lorem Ipsum is simply dummy text of the printing and <br> typesetting industry. <br>
                Lorem Ipsum has been the industry's standard dummy text <br> ever since the 1500s,
             </p>
             <button type="button"> Buy Now</button>
          </div>
       </div>
       <div class="carousel-item">
          <img src="<?php echo e(asset('assetes/images/Mask2.png')); ?>" class="img-fluid" alt="">
          <div class="slider_text">
             <h1>Inovative & Secure. <br>
                Crypto Exchange!
             </h1>
             <p>Lorem Ipsum is simply dummy text of the printing and <br> typesetting industry. <br>
                Lorem Ipsum has been the industry's standard dummy text <br> ever since the 1500s,
             </p>
             <button type="button"> Buy Now</button>
          </div>
       </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="fa fa-arrow-circle-o-left"></span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="fa fa-arrow-circle-o-right"></span>
    </a>
 </div>
 <!-- //// End Main Carousal  ////// -->
<?php /**PATH E:\xampp\htdocs\ATM\resources\views/Front_layout/slider.blade.php ENDPATH**/ ?>