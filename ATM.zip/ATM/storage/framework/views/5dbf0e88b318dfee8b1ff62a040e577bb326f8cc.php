    

    <?php $__env->startSection('content'); ?>


        <div class="set_form">
            <div class="card">
                <div class="card-header">
                    <h5 class="title">Add New Client</h5>
                </div>
                <form method="post" action="<?php echo e(route('createClient')); ?>" autocomplete="off" enctype="multipart/form-data">
                    <div class="card-body">
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="inputEmail4">Name</label>
                                <input type="text" name="name" class="form-control">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="inputPassword4">Last Name</label>
                                <input type="text" name="lname" class="form-control"   >
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="inputEmail4">Address</label>
                                <input type="text" name="address" class="form-control" >
                            </div>
                            <div class="form-group col-md-6">
                                <label for="inputPassword4">Email</label>
                                <input type="email" name="email" class="form-control"  >
                            </div>

                        </div>
                        <div class="form-row">

                            <div class="form-group col-md-6">
                                <label for="inputPassword4">Password</label>
                                <input type="password" name="password" class="form-control" >
                            </div>
                        </div>

                    </div>
                    <div class="card-footer pull-right">
                        <button type="submit" class="btn btn-fill btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>

    <?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ATM\resources\views/admin/client/add-client.blade.php ENDPATH**/ ?>