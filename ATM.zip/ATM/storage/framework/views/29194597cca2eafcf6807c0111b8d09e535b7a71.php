<?php $__env->startSection('content'); ?>
<style>

.sidebar .sidebar-wrapper>.nav [data-toggle="collapse"]~div>ul>li>a i, .sidebar .sidebar-wrapper .user .info [data-toggle="collapse"]~div>ul>li>a i, .off-canvas-sidebar .sidebar-wrapper>.nav [data-toggle="collapse"]~div>ul>li>a i, .off-canvas-sidebar .sidebar-wrapper .user .info [data-toggle="collapse"]~div>ul>li>a i {
  line-height: 32px;
}
.custom_color , .sorting_1 , table.dataTable.stripe tbody tr.odd, table.dataTable.display tbody tr.odd {
    background: #27293d !important;
}
.dataTables_wrapper .dataTables_length select {
    color: #fff !important;
}
.dataTables_wrapper .dataTables_length, .dataTables_wrapper .dataTables_filter, .dataTables_wrapper .dataTables_info, .dataTables_wrapper .dataTables_processing, .dataTables_wrapper .dataTables_paginate {
    color: #fff !important;
}
.dataTables_wrapper .dataTables_paginate .paginate_button.disabled, .dataTables_wrapper .dataTables_paginate .paginate_button.disabled:hover, .dataTables_wrapper .dataTables_paginate .paginate_button.disabled:active {
    color: #e7e4e4 !important;
}
.dataTables_wrapper .dataTables_paginate .paginate_button , .dataTables_wrapper .dataTables_filter input {
    color: #fff !important;
}
</style>



    <div class="content">
        <div class="row">
            <?php if(Session::has('message')): ?>
                <p class="alert alert-success"><?php echo e(Session::get('message')); ?></p>
            <?php endif; ?>
            <div class="col-md-12">
                <div class="card ">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-8">
                                <h4 class="card-title">Chat View</h4
                            </div>
                        </div>
                            <div class="col-4 text-right">
                                 <a href="<?php echo e(route('chat.index')); ?>" class="btn btn-sm btn-primary">Back</a>
                            </div>

                    </div>
                    <div class="card-body">

                        <div class="">
                            <table class="table tablesorter " id="myTable">
                                <thead class=" text-primary">
                                <tr class="custom_color">
                                    <th scope="col">Ticket Number</th>
                                    <th scope="col">User From</th>
                                    <th scope="col">User To</th>
                                    <th scope="col">Subject</th>
                                    <th scope="col">Message</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $chat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr class="custom_color" >
                                    <td><?php echo e($datum->ticket_no); ?></td>
                                    <td><?php echo e($datum->user_from); ?></td>
                                    <td><?php echo e($datum->user_to); ?></td>
                                    <td><?php echo e($datum->subject); ?></td>
                                    <td><?php echo e($datum->message); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <br>
                        <br>
                        <h2>Enter your reply</h2>
                        <form action="/adminReply" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group col-md-6">
                                <textarea name="message" id="" cols="100" rows="5"></textarea>
                            </div>
                            <input type="hidden" name="ticket_no" value="<?php echo e($chat[0]->ticket_no); ?>">
                            <input type="hidden" name="subject" value="<?php echo e($chat[0]->subject); ?>">
                            <input type="hidden" name="user_from" value="<?php echo e($chat[0]->user_from); ?>">
                            <input type="hidden" name="user_to" value="<?php echo e($chat[0]->user_to); ?>">
                            <input type="hidden" name="parent_id" value="<?php echo e($chat[1]->parent_id); ?>">
                            <div class="card-footer">
                                <button type="submit" class="btn btn-fill btn-primary">Reply</button>
                            </div>
                        </form>
                    </div>

                    <div class="card-footer py-4">
                        <nav class="d-flex justify-content-end" aria-label="...">

                        </nav>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', ['page' => __('User Profile'), 'pageSlug' => 'users'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ATM\resources\views/admin/chat/showChat.blade.php ENDPATH**/ ?>