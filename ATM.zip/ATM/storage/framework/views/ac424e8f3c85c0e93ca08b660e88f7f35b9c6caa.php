 <!-- /////  Fees section /////// -->
 <section class="fees">
    <div class="container">
       <div class="section_title text-center" data-aos="fade-down"  data-aos-duration="1000">
          <h2>Fees</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Gravida <br> tortor elit, , at viverra libero lectus et.</p>
       </div>
       <div class="progress_bars">
          <div class="circle-border"  data-aos="fade-up" data-aos-duration="1200">
             <div class="circle">
                <h2>Admin Fee</h2>
                <span>10%</span>
             </div>
             <i class="fa fa-circle"></i>
          </div>
          <div class="circle-border circle_main2" data-aos="fade-left" data-aos-duration="1400">
             <div class="circle">
                <h2>Shipping Fee</h2>
                <span>15%</span>
             </div>
             <i class="fa fa-circle"></i>
          </div>
          <div class="circle-border circle_main3" data-aos="flip-down" data-aos-duration="1600">
             <div class="circle">
                <h2>Mining ( Low )</h2>
                <span>20%</span>
             </div>
             <i class="fa fa-circle"></i>
          </div>
       </div>
    </div>
 </section>
 <!-- ///// End Fees section /////// -->
<?php /**PATH E:\xampp\htdocs\ATM\resources\views/Front_layout/fees.blade.php ENDPATH**/ ?>