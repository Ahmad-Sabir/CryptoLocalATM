<?php $__env->startSection('content'); ?>


<div class="modal-body">
    <form class="form-horizontal">
        <div class="login_title">
            <h2>Reset Password</h2>
        </div>
       <fieldset>
          <div class="group">
             <input required="" class="input" type="text"><span class="highlight"></span><span class="bar"></span>
             <label class="label" for="date">Email address</label>
          </div>
          <div class="control-group">
             <label class="control-label" for="forpassword"></label>
             <div class="controls">
                <button id="forpasswodr" name="forpassword" class="btn bitcoin_btn btn-block">Send</button>
             </div>
          </div>
       </fieldset>
    </form>
 </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Front_layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ATM\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>