
      <!-- ///// About /////// -->
      <section class="about" >
        <div class="container">
           <div class="about_text text-center" data-aos="zoom-out-down"  data-aos-duration="1200">
              <h2>What is Crypto currency? </h2>
              <p class="small_text">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
              <p class="large_text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Gravida tortor elit, , at viverra libero lectus et.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Gravida tortor elit, , at viverra libero lectus et.</p>
              <button class="custom-btn custom-btns light mt_20" type="button"><span>JOIN US NOW</span></button>
           </div>
        </div>
     </section>
     <!-- ///// End About /////// -->
<?php /**PATH E:\xampp\htdocs\multiple\resources\views/user/layouts/about.blade.php ENDPATH**/ ?>