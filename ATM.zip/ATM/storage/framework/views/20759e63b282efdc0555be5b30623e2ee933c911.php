<?php $__env->startSection('content'); ?>
    <div class="set_form">
        <div class="card">

            <div class="card-header">
                <h5 class="title">Client Edit</h5>
            </div>
            <?php if(Session::has('message')): ?>
                <p class="alert alert-info"><?php echo e(Session::get('message')); ?></p>
            <?php endif; ?>
            <form method="post" action="<?php echo e(route('updateClient',[$data->id])); ?>" autocomplete="off" enctype="multipart/form-data">
                <div class="card-body">
                    <?php echo csrf_field(); ?>
                    <div class="form-row">

                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Name</label>
                            <input type="text" name="name" value="<?php echo e($data->name); ?>" class="form-control">
                        </div>

                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Last Name</label>
                            <input type="text" name="lname" value="<?php echo e($data->lname); ?>" class="form-control">
                        </div>

                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Address</label>
                            <input type="text" name="address" value="<?php echo e($data->country); ?>" class="form-control">
                        </div>

                        <div class="form-group col-md-6">
                            <label for="inputEmail4">email</label>
                            <input type="email" name="email" value="<?php echo e($data->email); ?>" class="form-control">
                        </div>

                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Password</label>
                            <input type="password" name="password" value="" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label class="btn btn-outline-neutral">Client Image
                            <input type="file" name="client_image_id" >
                        </label>
                    </div>
                </div>
                <div class="card-footer pull-right">
                    <button type="submit" class="btn btn-fill btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ATM\resources\views/admin/client/edit-client.blade.php ENDPATH**/ ?>