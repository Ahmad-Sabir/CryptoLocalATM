<?php $__env->startSection('content'); ?>


    <div class="set_form">
        <div class="card">

            <div class="card-header">
                <h5 class="title">Code Edit</h5>
            </div>
            <?php if(Session::has('message')): ?>
                <p class="alert alert-info"><?php echo e(Session::get('message')); ?></p>
            <?php endif; ?>
            <form method="post" action="<?php echo e(route('updateCode',[$data->id])); ?>" autocomplete="off">
                <div class="card-body">
                    <?php echo csrf_field(); ?>
                    <div class="form-row">

                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Name</label>
                            <input type="text" name="name" value="<?php echo e($data->name); ?>" class="form-control">
                        </div>

                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Voucher</label>
                            <input type="text" name="voucher" value="<?php echo e($data->voucher); ?>" class="form-control">
                        </div>

                        <div class="form-group col-md-6">
                            <label for="inputEmail4">QR Code</label>
                            <input type="text" name="qr_code" value="<?php echo e($data->qr_code); ?>" class="form-control">
                        </div>

                    </div>
                </div>


                <div class="card-footer pull-right">
                    <button type="submit" class="btn btn-fill btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ATM\resources\views/admin/codes/edit-code.blade.php ENDPATH**/ ?>