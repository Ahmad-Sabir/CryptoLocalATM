<?php $__env->startSection('content'); ?>


    <div class="set_form">
        <div class="card">
            <div class="card-header">
                <h5 class="title"></h5>
            </div>
                <form method="post" action="<?php echo e(route('createorder')); ?>" autocomplete="off" enctype="multipart/form-data">
                    <div class="card-body">
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="order"><b>Order Id</b></label>
                                <input type="text" name="order_id" class="form-control">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="product">Product Name</label>
                                <input type="text" name="product-name" class="form-control"   >
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="status">Order Status</label><br><br>
                                <select name="subscription" class="form-group">
                                    <option value="">Select values</option>
                                    <option value="active">Active</option>
                                    <option value="disactive">Disactive</option>

                                </select>
                            </div>
                    </div>
                    <div class="card-footer pull-right">
                        <button type="submit" class="btn btn-fill btn-primary">save</button>
                    </div>
                </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ATM\resources\views/admin/orders/order.blade.php ENDPATH**/ ?>